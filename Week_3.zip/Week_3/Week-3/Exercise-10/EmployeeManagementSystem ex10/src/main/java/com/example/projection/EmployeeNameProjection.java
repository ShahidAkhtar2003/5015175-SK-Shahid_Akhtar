package com.example.projection;

public interface EmployeeNameProjection {
    String getName();
}
